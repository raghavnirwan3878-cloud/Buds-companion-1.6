# Buds Companion 1.7 — selected feature update

Based on the supplied Buds Companion 1.6 source.

Included:
- 5.1 Game/low-latency mode state UI
- 5.2 Low-latency status indicator
- 5.3 Game-mode Quick Settings tile
- 6.1 Battery history
- 6.6 Usage history
- 6.9 Low-battery notifications
- 6.10 Configurable low-battery threshold
- 7.1 Device name
- 7.2 Model/device information
- 7.3 Firmware information UI
- 9.1–9.8 notifications and notification controls
- 10.2 Battery Quick Settings tile
- 10.5 Game-mode Quick Settings tile
- 12.x Material 3 / DayNight UI, animations, status/error/loading presentation
- Foreground app refresh every 2 seconds while MainActivity is resumed

Important protocol boundary:
- OppoProtocol.java was not modified.
- Existing RFCOMM/SPP connection UUID, socket fallback, discovery cancellation,
  reconnect/backoff, and background 10-second polling were preserved.
- The supplied protocol parser does not expose a firmwareText field and does not
  define a verified command for changing game mode. The 1.7 build therefore does
  not invent either wire format. Firmware remains "Not reported by current
  protocol parser", and Game Mode is stored/displayed as app state only.
