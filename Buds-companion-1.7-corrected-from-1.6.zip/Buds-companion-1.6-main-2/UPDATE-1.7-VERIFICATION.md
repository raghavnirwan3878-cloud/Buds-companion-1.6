# Buds Companion 1.7 verification

Base: user-supplied `Buds-companion-1.6-main-2.zip`.

Version:
- versionCode 7
- versionName 1.7

Selected features:
- 5.1, 5.2, 5.3
- 6.1, 6.6, 6.9, 6.10
- 7.1, 7.2, 7.3
- 9.1–9.8
- 10.2, 10.5
- 12.x UI/UX
- 2-second foreground refresh while MainActivity is resumed

Protocol safety:
- OppoProtocol.java was preserved unchanged.
- Existing RFCOMM/SPP UUID and connection/reconnect implementation were preserved.
- Existing background 10-second polling was preserved.
- No unverified Game Mode wire command was invented.
- No unsupported firmwareText field is referenced.
- Firmware UI truthfully reports that the current protocol parser does not expose firmware data.

Build note:
- The uploaded 1.6 source contains no Gradle wrapper, so this runtime cannot perform
  the final Gradle build. Build in GitHub Codespaces/Actions.
